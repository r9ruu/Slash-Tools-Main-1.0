import os
import sys
import time
import json
import requests
import socket
import re
import datetime
import random
import string
import threading
from colorama import init, Fore, Style

init(autoreset=True)

# ============================================================
# ASCII ART LOGO
# ============================================================

LOGO = r"""
                   .:+*#%%#####*++++-.
                :#%%*+*+-.....
             .=%%+++:..
           .=%#++=.
          -%%+++.
      .  =%%++-          ....
      #%+#%++=.        .:#%%%*:
      :#@%#+=          :*+:-*%#:
       .*@@#.         .-%*::-%%#.
        .-%@@%-.      .=%%--%%%-
          .:--=*+-:.:-#%%%%%%%%*.
              .:-*#%%%%%%%%%%%%%-
                 .+%%%*+*%%%%%%%%+...
                 .+%@@%%%%*#%%%%%%%%%*-.
                  .*%@%%%%%%%%%%%%%%%%%#-.
                   .*%%%%%%%%%%%+#%%%%%%%%%*-.
                  .=%%%%%%%%%%%%@%*%%%%%####=-==
                  :*%%%%%%%%%%%%%%%*#%%%%#+=-==+
                 .+=*%#%%%%%%%%%%%%%**%%#+**+-:-
                .-=::*-%%%%%%%%%%%%###*-*%###+:
                ...:..%%%%%%%%%%%%%%#:=*+-:.
                     *%%%%%%%%%%%%%%%%.
                    :#%%%%%%%%%%%%%%%%+
                   .*%%%%%%%%%%%%%%%%%#.
                  .=%%%%%%%%%%%%%%%%%%#:.
                  .+%%%%%%%%%%%%%%%%%%%*.
                    :+*#%%%@%%%%%%%%%%%%#:.
                      ..:==+*#%#*=-:.:-+***:.
"""

# ============================================================
# COLOR SCHEMES
# ============================================================

COLORS = {
    '1': ('RED', Fore.RED),
    '2': ('GREEN', Fore.GREEN),
    '3': ('BLUE', Fore.BLUE),
    '4': ('YELLOW', Fore.YELLOW),
    '5': ('MAGENTA', Fore.MAGENTA),
    '6': ('CYAN', Fore.CYAN),
    '7': ('WHITE', Fore.WHITE),
    '8': ('LIGHT RED', Fore.LIGHTRED_EX),
    '9': ('LIGHT GREEN', Fore.LIGHTGREEN_EX),
    '10': ('LIGHT BLUE', Fore.LIGHTBLUE_EX),
    '11': ('LIGHT YELLOW', Fore.LIGHTYELLOW_EX),
    '12': ('LIGHT MAGENTA', Fore.LIGHTMAGENTA_EX),
    '13': ('LIGHT CYAN', Fore.LIGHTCYAN_EX),
    '14': ('LIGHT WHITE', Fore.LIGHTWHITE_EX),
}

# ============================================================
# UTILITY FUNCTIONS
# ============================================================

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_logo(color):
    clear()
    print(color + LOGO)
    time.sleep(1.5)

def print_banner(color, title):
    print(color + "=" * 60)
    print(color + f"  {title}")
    print(color + "=" * 60)

def loading_animation(color, text, duration=2):
    frames = ["|", "/", "-", "\\"]
    end = time.time() + duration
    i = 0
    while time.time() < end:
        print(f"\r{color}{frames[i]} {text}", end="")
        i = (i + 1) % len(frames)
        time.sleep(0.1)
    print()

def save_results(data, filename="results.txt"):
    """Save results to a file"""
    with open(filename, "a", encoding="utf-8") as f:
        f.write(json.dumps(data, indent=2, default=str) + "\n")
    return filename

# ============================================================
# OSINT - IP LOOKUP
# ============================================================

def ip_lookup(ip):
    """Get public info about an IP address"""
    try:
        loading_animation(Fore.YELLOW, "Querying IP databases...")
        r = requests.get(f"http://ip-api.com/json/{ip}", timeout=5)
        if r.status_code == 200:
            data = r.json()
            if data.get('status') == 'success':
                return {
                    'ip': data.get('query'),
                    'country': data.get('country'),
                    'country_code': data.get('countryCode'),
                    'region': data.get('regionName'),
                    'city': data.get('city'),
                    'zip': data.get('zip'),
                    'lat': data.get('lat'),
                    'lon': data.get('lon'),
                    'timezone': data.get('timezone'),
                    'isp': data.get('isp'),
                    'org': data.get('org'),
                    'as': data.get('as')
                }
        return None
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - EMAIL LOOKUP
# ============================================================

def email_lookup(email):
    """Verify email format and domain"""
    try:
        loading_animation(Fore.YELLOW, "Analyzing email...")
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        if not re.match(pattern, email):
            return {'error': 'Invalid email format'}
        
        domain = email.split('@')[1]
        result = {
            'email': email,
            'domain': domain,
            'valid_format': True
        }
        
        # Check if domain exists
        try:
            socket.gethostbyname(domain)
            result['domain_exists'] = True
        except:
            result['domain_exists'] = False
        
        # Check common providers
        providers = {
            'gmail.com': 'Google',
            'yahoo.com': 'Yahoo',
            'outlook.com': 'Microsoft',
            'hotmail.com': 'Microsoft',
            'protonmail.com': 'ProtonMail',
            'icloud.com': 'Apple',
            'aol.com': 'AOL',
            'zoho.com': 'Zoho'
        }
        
        if domain in providers:
            result['provider'] = providers[domain]
        
        return result
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - PHONE LOOKUP
# ============================================================

def phone_lookup(phone):
    """Get public info about a phone number"""
    try:
        loading_animation(Fore.YELLOW, "Querying phone databases...")
        
        # Basic validation
        phone = phone.strip()
        if not phone.startswith('+'):
            return {'error': 'Use international format (+33123456789)'}
        
        # Extract country code
        country_codes = {
            '33': 'France', '1': 'USA/Canada', '44': 'UK', '49': 'Germany',
            '32': 'Belgium', '41': 'Switzerland', '34': 'Spain', '39': 'Italy',
            '31': 'Netherlands', '48': 'Poland', '351': 'Portugal', '46': 'Sweden',
            '47': 'Norway', '45': 'Denmark', '358': 'Finland', '30': 'Greece',
            '90': 'Turkey', '7': 'Russia', '86': 'China', '81': 'Japan',
            '82': 'South Korea', '55': 'Brazil', '52': 'Mexico', '91': 'India',
            '61': 'Australia', '64': 'New Zealand', '27': 'South Africa',
            '20': 'Egypt', '971': 'UAE', '966': 'Saudi Arabia', '972': 'Israel'
        }
        
        # Find country code (check 3 digits first, then 2, then 1)
        code_3 = phone[1:4]
        code_2 = phone[1:3]
        code_1 = phone[1:2]
        
        country = None
        code = None
        if code_3 in country_codes:
            country = country_codes[code_3]
            code = code_3
        elif code_2 in country_codes:
            country = country_codes[code_2]
            code = code_2
        elif code_1 in country_codes:
            country = country_codes[code_1]
            code = code_1
        
        if not country:
            return {'error': 'Unknown country code'}
        
        # Try numverify API (free tier)
        try:
            api_key = "YOUR_FREE_API_KEY_HERE"  # Get from numverify.com
            r = requests.get(f"http://apilayer.net/api/validate?access_key={api_key}&number={phone}&country_code={code}", timeout=5)
            if r.status_code == 200:
                data = r.json()
                if data.get('valid'):
                    return {
                        'phone': phone,
                        'country': country,
                        'country_code': '+' + code,
                        'carrier': data.get('carrier'),
                        'line_type': data.get('line_type'),
                        'location': data.get('location'),
                        'international_format': data.get('international_format')
                    }
        except:
            pass
        
        # Fallback to basic info
        return {
            'phone': phone,
            'country': country,
            'country_code': '+' + code,
            'note': 'Limited info without API key. Get free key at numverify.com'
        }
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - USERNAME LOOKUP
# ============================================================

def username_lookup(username):
    """Check username availability across platforms"""
    try:
        loading_animation(Fore.YELLOW, "Searching platforms...")
        
        platforms = {
            'GitHub': f"https://github.com/{username}",
            'Twitter/X': f"https://twitter.com/{username}",
            'Instagram': f"https://instagram.com/{username}",
            'Reddit': f"https://reddit.com/user/{username}",
            'Twitch': f"https://twitch.tv/{username}",
            'YouTube': f"https://youtube.com/@{username}",
            'TikTok': f"https://tiktok.com/@{username}",
            'Snapchat': f"https://snapchat.com/add/{username}",
            'Pinterest': f"https://pinterest.com/{username}",
            'Steam': f"https://steamcommunity.com/id/{username}",
            'Discord': f"https://discord.com/users/{username}",
            'Spotify': f"https://open.spotify.com/user/{username}",
            'SoundCloud': f"https://soundcloud.com/{username}",
            'DeviantArt': f"https://deviantart.com/{username}",
            'Vimeo': f"https://vimeo.com/{username}",
            'Dribbble': f"https://dribbble.com/{username}",
            'Behance': f"https://behance.net/{username}",
            'Medium': f"https://medium.com/@{username}",
            'Quora': f"https://quora.com/profile/{username}",
            'Patreon': f"https://patreon.com/{username}"
        }
        
        results = {}
        for platform, url in platforms.items():
            try:
                r = requests.get(url, timeout=3)
                results[platform] = r.status_code == 200
            except:
                results[platform] = False
        
        return results
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - DISCORD ID LOOKUP
# ============================================================

def discord_id_lookup(user_id):
    """Get creation date from Discord ID"""
    try:
        loading_animation(Fore.YELLOW, "Decoding Discord ID...")
        
        if not user_id.isdigit():
            return {'error': 'Invalid Discord ID'}
        
        # Discord ID contains timestamp
        timestamp = (int(user_id) >> 22) + 1420070400000
        date = datetime.datetime.utcfromtimestamp(timestamp / 1000)
        
        return {
            'id': user_id,
            'created': date.strftime('%Y-%m-%d %H:%M:%S'),
            'age_days': (datetime.datetime.utcnow() - date).days,
            'age_years': round((datetime.datetime.utcnow() - date).days / 365, 1)
        }
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - DOMAIN LOOKUP
# ============================================================

def domain_lookup(domain):
    """Get DNS and WHOIS info about a domain"""
    try:
        loading_animation(Fore.YELLOW, "Querying DNS records...")
        
        result = {'domain': domain}
        
        # DNS resolution
        try:
            ip = socket.gethostbyname(domain)
            result['ip'] = ip
        except:
            result['ip'] = 'Could not resolve'
        
        # Try WHOIS via API (free tier)
        try:
            r = requests.get(f"https://rdap.org/domain/{domain}", timeout=5)
            if r.status_code == 200:
                data = r.json()
                result['registrar'] = data.get('entities', [{}])[0].get('vcardArray', [[], []])[1][0][3] if data.get('entities') else 'N/A'
                result['creation_date'] = data.get('events', [{}])[0].get('eventDate', 'N/A')
        except:
            pass
        
        # Common subdomains check
        subdomains = ['www', 'mail', 'ftp', 'admin', 'api', 'dev', 'test', 'beta']
        found = []
        for sub in subdomains:
            try:
                socket.gethostbyname(f"{sub}.{domain}")
                found.append(sub)
            except:
                pass
        result['found_subdomains'] = found
        
        return result
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# OSINT - SOCIAL MEDIA SEARCH
# ============================================================

def social_media_search(name):
    """Search for a name across platforms"""
    try:
        loading_animation(Fore.YELLOW, "Searching social media...")
        
        # Generate possible usernames
        name_parts = name.lower().split()
        usernames = []
        if len(name_parts) >= 2:
            usernames.append(name_parts[0] + name_parts[1])
            usernames.append(name_parts[0] + "." + name_parts[1])
            usernames.append(name_parts[0] + "_" + name_parts[1])
            usernames.append(name_parts[0] + name_parts[1][0])
            usernames.append(name_parts[0][0] + name_parts[1])
            usernames.append(name_parts[0] + str(random.randint(1, 999)))
        elif len(name_parts) == 1:
            usernames.append(name_parts[0])
            usernames.append(name_parts[0] + str(random.randint(1, 999)))
        
        results = {}
        for username in usernames[:5]:
            platforms = {
                'GitHub': f"https://github.com/{username}",
                'Twitter': f"https://twitter.com/{username}",
                'Instagram': f"https://instagram.com/{username}",
                'Reddit': f"https://reddit.com/user/{username}",
                'Twitch': f"https://twitch.tv/{username}"
            }
            for platform, url in platforms.items():
                try:
                    r = requests.get(url, timeout=3)
                    if r.status_code == 200:
                        results[f"{platform} ({username})"] = True
                except:
                    pass
        
        return results if results else {'error': 'No profiles found'}
    except Exception as e:
        return {'error': str(e)}

# ============================================================
# GENERATORS
# ============================================================

def generate_password(length=16):
    """Generate a secure password"""
    chars = string.ascii_letters + string.digits + "!@#$%^&*()_+-=[]{}|;:,.<>?"
    return ''.join(random.choice(chars) for _ in range(length))

def generate_username():
    """Generate a random username"""
    prefixes = ["Dark", "Shadow", "Cyber", "Mega", "Ultra", "Pro", "X", "Hyper", "Super", "Neo"]
    suffixes = ["King", "Lord", "Master", "Hunter", "Warrior", "Ninja", "Slayer", "Boss", "Wolf", "Tiger"]
    return f"{random.choice(prefixes)}{random.choice(suffixes)}{random.randint(1, 999)}"

def generate_email():
    """Generate a random email"""
    domains = ["gmail.com", "yahoo.com", "outlook.com", "protonmail.com", "hotmail.com"]
    return f"{generate_username().lower()}@{random.choice(domains)}"

def generate_phone():
    """Generate a random phone number"""
    country_codes = ['+33', '+1', '+44', '+49', '+32', '+41', '+34', '+39']
    code = random.choice(country_codes)
    if code == '+33':
        number = '0' + str(random.randint(100000000, 999999999))
    elif code == '+1':
        number = str(random.randint(2000000000, 9999999999))
    else:
        number = str(random.randint(100000000, 999999999))
    return f"{code} {number}"

def generate_ip():
    """Generate a random IP address"""
    return f"{random.randint(1, 223)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"

def generate_discord_token():
    """Generate a Discord token (format only)"""
    chars = string.ascii_letters + string.digits
    return f"{''.join(random.choice(chars) for _ in range(24))}.{''.join(random.choice(chars) for _ in range(6))}.{''.join(random.choice(chars) for _ in range(27))}"

def generate_webhook():
    """Generate a webhook URL (format only)"""
    chars = string.ascii_letters + string.digits
    return f"https://discord.com/api/webhooks/{random.randint(100000000000000000, 999999999999999999)}/{''.join(random.choice(chars) for _ in range(68))}"

# ============================================================
# MENUS
# ============================================================

def main_menu(color):
    clear()
    print(color + LOGO)
    print(color + "=" * 60)
    print(color + "  OSINT TOOL - https://github.com/r9ruu/Slash-Tools-Main-1.0/tree/main")
    print(color + "  Version 1.0 | English")
    print(color + "=" * 60)
    print(color + "  [1] IP Lookup")
    print(color + "  [2] Email Lookup")
    print(color + "  [3] Phone Lookup")
    print(color + "  [4] Username Lookup")
    print(color + "  [5] Discord ID Lookup")
    print(color + "  [6] Domain Lookup")
    print(color + "  [7] Social Media Search")
    print(color + "  [8] Generators")
    print(color + "  [9] Save Results")
    print(color + "  [0] Exit")
    print(color + "=" * 60)

def generators_menu(color):
    clear()
    print(color + "=" * 60)
    print(color + "  GENERATORS")
    print(color + "=" * 60)
    print(color + "  [1] Password")
    print(color + "  [2] Username")
    print(color + "  [3] Email")
    print(color + "  [4] Phone Number")
    print(color + "  [5] IP Address")
    print(color + "  [6] Discord Token (format only)")
    print(color + "  [7] Webhook URL (format only)")
    print(color + "  [0] Back")
    print(color + "=" * 60)

# ============================================================
# MAIN
# ============================================================

def main():
    # Display logo and ask for color
    clear()
    print(LOGO)
    time.sleep(1)
    
    print("\n" + "=" * 60)
    print("  SELECT TEXT COLOR")
    print("=" * 60)
    for key, (name, _) in COLORS.items():
        print(f"  [{key}] {name}")
    print("=" * 60)
    
    color_choice = input("> ")
    color = COLORS.get(color_choice, ('RED', Fore.RED))[1]
    
    # Loading animation
    clear()
    loading_animation(color, "Initializing OSINT Tool...", 2)
    time.sleep(0.5)
    
    # Main loop
    while True:
        main_menu(color)
        choice = input(color + "> ")
        
        if choice == "1":
            clear()
            print_banner(color, "IP LOOKUP")
            ip = input(color + "Enter IP address: ")
            result = ip_lookup(ip)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for key, value in result.items():
                    print(color + f"    {key}: {value}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "2":
            clear()
            print_banner(color, "EMAIL LOOKUP")
            email = input(color + "Enter email address: ")
            result = email_lookup(email)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for key, value in result.items():
                    print(color + f"    {key}: {value}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "3":
            clear()
            print_banner(color, "PHONE LOOKUP")
            phone = input(color + "Enter phone number (+33123456789): ")
            result = phone_lookup(phone)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for key, value in result.items():
                    print(color + f"    {key}: {value}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "4":
            clear()
            print_banner(color, "USERNAME LOOKUP")
            username = input(color + "Enter username: ")
            result = username_lookup(username)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for platform, found in result.items():
                    status = "[+] FOUND" if found else "[-] Not found"
                    print(color + f"    {platform}: {status}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "5":
            clear()
            print_banner(color, "DISCORD ID LOOKUP")
            user_id = input(color + "Enter Discord ID: ")
            result = discord_id_lookup(user_id)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for key, value in result.items():
                    print(color + f"    {key}: {value}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "6":
            clear()
            print_banner(color, "DOMAIN LOOKUP")
            domain = input(color + "Enter domain (example.com): ")
            result = domain_lookup(domain)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for key, value in result.items():
                    print(color + f"    {key}: {value}")
            else:
                print(color + "\n[-] " + (result.get('error', 'No results found') if result else 'No results found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "7":
            clear()
            print_banner(color, "SOCIAL MEDIA SEARCH")
            name = input(color + "Enter name to search: ")
            result = social_media_search(name)
            if result and 'error' not in result:
                print(color + "\n[+] Results:")
                for platform, found in result.items():
                    print(color + f"    {platform}: FOUND")
            else:
                print(color + "\n[-] " + (result.get('error', 'No profiles found') if result else 'No profiles found'))
            input(color + "\nPress Enter to continue...")
        
        elif choice == "8":
            while True:
                generators_menu(color)
                gen_choice = input(color + "> ")
                
                if gen_choice == "1":
                    length = int(input(color + "Password length (8-64): "))
                    print(color + f"\n[+] Generated: {generate_password(length)}")
                elif gen_choice == "2":
                    print(color + f"\n[+] Generated: {generate_username()}")
                elif gen_choice == "3":
                    print(color + f"\n[+] Generated: {generate_email()}")
                elif gen_choice == "4":
                    print(color + f"\n[+] Generated: {generate_phone()}")
                elif gen_choice == "5":
                    print(color + f"\n[+] Generated: {generate_ip()}")
                elif gen_choice == "6":
                    print(color + f"\n[+] Generated: {generate_discord_token()}")
                    print(color + "    [NOTE] Format only - not functional")
                elif gen_choice == "7":
                    print(color + f"\n[+] Generated: {generate_webhook()}")
                    print(color + "    [NOTE] Format only - not functional")
                elif gen_choice == "0":
                    break
                input(color + "\nPress Enter to continue...")
        
        elif choice == "9":
            clear()
            print_banner(color, "SAVE RESULTS")
            print(color + "  Results are saved to results.txt")
            print(color + "  You can use the '>' operator to save output")
            input(color + "\nPress Enter to continue...")
        
        elif choice == "0":
            clear()
            print(color + "Exiting... Goodbye!")
            time.sleep(1)
            break

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{Fore.RED}Interrupted. Exiting...")
    except Exception as e:
        print(f"\n{Fore.RED}Error: {e}")
        input("Press Enter to continue...")
